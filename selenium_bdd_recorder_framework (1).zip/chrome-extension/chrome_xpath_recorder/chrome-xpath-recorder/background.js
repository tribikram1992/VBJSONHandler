let recordedSteps = [];
chrome.runtime.onMessage.addListener((msg) => {
  recordedSteps.push(msg);
});
chrome.runtime.onInstalled.addListener(() => {
  console.log("XPath Recorder installed.");
});