function getXPath(element) {
  if (element.id !== "") return '//*[@id="' + element.id + '"]';
  if (element === document.body) return '/html/body';
  let ix = 0;
  let siblings = element.parentNode.childNodes;
  for (let i = 0; i < siblings.length; i++) {
    let sibling = siblings[i];
    if (sibling === element) return getXPath(element.parentNode) + '/' + element.tagName.toLowerCase() + '[' + (ix + 1) + ']';
    if (sibling.nodeType === 1 && sibling.tagName === element.tagName) ix++;
  }
}

function recordAction(action, element, value = "") {
  const xpath = getXPath(element);
  chrome.runtime.sendMessage({ xpath, action, value, tag: element.tagName, frame: window.location.href });
}

document.addEventListener("click", (e) => recordAction("click", e.target));
document.addEventListener("dblclick", (e) => recordAction("doubleClick", e.target));
document.addEventListener("contextmenu", (e) => recordAction("rightClick", e.target));
document.addEventListener("input", (e) => recordAction("input", e.target, e.target.value));
document.addEventListener("change", (e) => {
  if (e.target.tagName === "SELECT") {
    recordAction("select", e.target, e.target.value);
  }
});
document.addEventListener("mouseover", (e) => recordAction("hover", e.target));