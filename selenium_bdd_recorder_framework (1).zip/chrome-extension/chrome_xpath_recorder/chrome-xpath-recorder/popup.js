document.getElementById('download').addEventListener('click', () => {
  chrome.runtime.getBackgroundPage((bg) => {
    const steps = bg.recordedSteps;
    const blob = new Blob([JSON.stringify(steps, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({
      url: url,
      filename: 'recordedSteps.json'
    });
  });
});