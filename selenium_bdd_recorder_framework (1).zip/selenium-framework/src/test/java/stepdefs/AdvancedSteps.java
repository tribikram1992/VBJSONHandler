package stepdefs;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import io.cucumber.java.en.*;
import java.time.Duration;

public class AdvancedSteps {
    WebDriver driver;
    WebDriverWait wait;
    Actions actions;

    public AdvancedSteps() {
        this.driver = utils.DriverFactory.getDriver();
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.actions = new Actions(driver);
    }

    @When("user double clicks on element {string}")
    public void doubleClick(String xpath) {
        WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
        actions.doubleClick(el).perform();
    }

    @When("user right clicks on element {string}")
    public void rightClick(String xpath) {
        WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
        actions.contextClick(el).perform();
    }

    @When("user drags element {string} and drops on {string}")
    public void dragAndDrop(String sourceXpath, String targetXpath) {
        WebElement source = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sourceXpath)));
        WebElement target = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(targetXpath)));
        actions.dragAndDrop(source, target).perform();
    }

    @When("user accepts the alert")
    public void acceptAlert() {
        wait.until(ExpectedConditions.alertIsPresent()).accept();
    }

    @When("user dismisses the alert")
    public void dismissAlert() {
        wait.until(ExpectedConditions.alertIsPresent()).dismiss();
    }
}