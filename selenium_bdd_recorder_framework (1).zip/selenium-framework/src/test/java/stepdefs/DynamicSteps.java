package stepdefs;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import io.cucumber.java.en.*;
import java.time.Duration;

public class DynamicSteps {
    WebDriver driver;
    WebDriverWait wait;
    Actions actions;

    public DynamicSteps() {
        this.driver = DriverFactory.getDriver();
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.actions = new Actions(driver);
    }

    @When("user clicks on element {string}")
    public void click(String xpath) {
        WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
        el.click();
    }

    @When("user enters {string} into element {string}")
    public void input(String value, String xpath) {
        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
        el.clear();
        el.sendKeys(value);
    }

    @When("user selects {string} from dropdown {string}")
    public void select(String value, String xpath) {
        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
        new Select(el).selectByVisibleText(value);
    }

    @When("user hovers over element {string}")
    public void hover(String xpath) {
        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
        actions.moveToElement(el).perform();
    }
}