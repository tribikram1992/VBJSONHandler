package utils;

import com.opencsv.CSVReader;
import java.io.FileReader;
import java.util.*;

public class CsvDataUtil {
    public static List<Map<String, String>> readCsv(String filePath) {
        List<Map<String, String>> records = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            String[] header = reader.readNext();
            String[] line;
            while ((line = reader.readNext()) != null) {
                Map<String, String> record = new LinkedHashMap<>();
                for (int i = 0; i < header.length; i++) {
                    record.put(header[i], line[i]);
                }
                records.add(record);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return records;
    }
}